=== WooTan ===
Contributors: Derwent
Donate link:
Tags:
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Requires at least: 3.5
Tested up to: 3.5
Stable tag: 0.1

Tailored Woocommerce extensions for TechnoTan namely a customized shipping plugin

== Description ==

Tailored Woocommerce extensions for TechnoTan namely a customized shipping plugin

== Installation ==


== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 0.1 =
- Initial Revision
